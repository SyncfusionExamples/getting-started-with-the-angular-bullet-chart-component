import { Component, ViewEncapsulation, ViewChild, OnInit } from '@angular/core';
import { QueryBuilderComponent, RuleModel, RuleChangeEventArgs } from '@syncfusion/ej2-angular-querybuilder';
import { GridComponent } from '@syncfusion/ej2-angular-grids';
import { DataManager, Query, ReturnOption, Predicate } from '@syncfusion/ej2-data';
import {employeeData} from './data'
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css'],
  encapsulation: ViewEncapsulation.None
})

export class AppComponent implements OnInit {
  title = 'myangularproject';

  @ViewChild('queryBuilder', { static: false }) qryBldrObj!: QueryBuilderComponent;
  @ViewChild('dataGrid', { static: false }) grid!: GridComponent;

  values: string[] = ['Mr.', 'Mrs.'];

  gridDataSource: object[] = employeeData;

  public onChange(){
    this.qryBldrObj.setRules(this.importRules);
    this.updateRule({rule: this.qryBldrObj.getValidRules(this.qryBldrObj.rule)})
  }

  public updateRule(args: RuleChangeEventArgs){
    const predicate: Predicate = this.qryBldrObj.getPredicate(args.rule);
    const fltrDataSource: Object[] = [];
    let dataManagerQuery: Query;
    if (typeof predicate === 'undefined' || predicate === null) {
        dataManagerQuery = new Query().select(['EmployeeID', 'FirstName', 'TitleOfCourtesy', 'Title', 'Country', 'City']);
    } else {
        dataManagerQuery = new Query().select(['EmployeeID', 'FirstName', 'TitleOfCourtesy', 'Title', 'Country', 'City'])
            .where(predicate);
    }
    new DataManager(employeeData)
        .executeQuery(dataManagerQuery)
        .then((e: ReturnOption) => {
            (<Object[]>e.result).forEach((data: Object) => {
                fltrDataSource.push(data);
            });
        });
    this.gridDataSource = fltrDataSource;
    this.grid.refresh();
  }

  public onGridCreated(){
    this.updateRule({rule: this.qryBldrObj.getValidRules(this.qryBldrObj.rule)})
  }

  public importRules: RuleModel = {
    'condition': 'or',
    'rules': [{
      'label': 'Title',
      'field': 'Title',
      'type': 'string',
      'operator': 'endswith',
      'value': 'Representative'
    }]
  };

  ngOnInit(){
    
  }
}